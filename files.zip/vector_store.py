"""
Vector Store: ChromaDB interface.
Handles both writes (from consumer) and reads (from UI query).
"""

import os
import logging
from typing import List, Tuple
import chromadb
from chromadb.config import Settings
from dotenv import load_dotenv
from retriever.embedder import Chunk

load_dotenv()
log = logging.getLogger(__name__)

CHROMA_DIR = os.getenv("CHROMA_PERSIST_DIR", "./chroma_store")
COLLECTION_NAME = "documents"


class VectorStore:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=CHROMA_DIR,
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},  # cosine similarity
        )
        log.info(f"ChromaDB ready. Collection: {COLLECTION_NAME}, "
                 f"docs: {self.collection.count()}")

    def upsert(self, chunks: List[Chunk], embeddings: List[List[float]]):
        """Write chunks + embeddings to Chroma. Upsert = safe for re-ingestion."""
        self.collection.upsert(
            ids=[c.chunk_id for c in chunks],
            embeddings=embeddings,
            documents=[c.text for c in chunks],
            metadatas=[{
                "source": c.source,
                "page": c.page,
                "chunk_index": c.chunk_index,
            } for c in chunks],
        )
        log.info(f"Upserted {len(chunks)} chunks. Total in store: {self.collection.count()}")

    def query(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        source_filter: str = None,
    ) -> List[dict]:
        """
        Retrieve top-k similar chunks.
        Optionally filter by source filename.
        Returns list of {text, source, page, distance}.
        """
        where = {"source": source_filter} if source_filter else None

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, self.collection.count() or 1),
            where=where,
            include=["documents", "metadatas", "distances"],
        )

        hits = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            hits.append({
                "text": doc,
                "source": meta["source"],
                "page": meta["page"],
                "distance": dist,
            })
        return hits

    def list_sources(self) -> List[str]:
        """Return all unique document sources in the store."""
        if self.collection.count() == 0:
            return []
        all_meta = self.collection.get(include=["metadatas"])["metadatas"]
        return list({m["source"] for m in all_meta})
