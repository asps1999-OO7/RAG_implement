"""
Reranker: Cross-encoder reranking of retrieved chunks.

Why this matters:
- Vector similarity retrieves semantically close chunks (recall-oriented)
- Cross-encoder scores (query, chunk) pairs directly (precision-oriented)
- Combining both = significantly better final context quality

This is what separates production RAG from tutorial RAG.
"""

import logging
from typing import List
from sentence_transformers import CrossEncoder

log = logging.getLogger(__name__)

RERANK_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"


class Reranker:
    def __init__(self):
        log.info(f"Loading rerank model: {RERANK_MODEL}")
        self.model = CrossEncoder(RERANK_MODEL)
        log.info("Reranker ready.")

    def rerank(self, query: str, hits: List[dict], top_n: int = 3) -> List[dict]:
        """
        Score each (query, chunk_text) pair, return top_n by score.
        Adds 'rerank_score' to each hit.
        """
        if not hits:
            return []

        pairs = [(query, hit["text"]) for hit in hits]
        scores = self.model.predict(pairs)

        for hit, score in zip(hits, scores):
            hit["rerank_score"] = float(score)

        reranked = sorted(hits, key=lambda x: x["rerank_score"], reverse=True)
        top = reranked[:top_n]

        log.info(f"Reranked {len(hits)} → kept top {len(top)}")
        return top
