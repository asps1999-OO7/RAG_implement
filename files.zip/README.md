# Kafka-RAG: Real-Time Knowledge Pipeline

A RAG system where the knowledge base is a **live streaming pipeline** — drop a PDF into the `/docs` folder and it becomes queryable within seconds, without restarting anything.

## Architecture

```
/docs folder (new PDF dropped)
        │
        ▼
 Producer (watchdog)
 watches folder for new files
        │
        ▼
 Kafka Topic: document-events
 partition key: filename
        │
        ▼
 Consumer (always running)
 - parses PDF → PyMuPDF
 - chunks text → RecursiveCharacterSplitter
 - embeds chunks → sentence-transformers
 - writes vectors → ChromaDB
        │
        ▼
 Streamlit UI
 - user types question
 - query embedded → similarity search → reranker
 - top chunks assembled into prompt
 - Groq LLM (Llama3) generates answer
 - source citations shown
```

## Why This Is Different From Tutorial RAG

| Tutorial RAG | This Project |
|---|---|
| Static batch ingestion | Real-time Kafka-driven ingestion |
| LangChain magic chains | Manual retrieval pipeline (explicit control) |
| No reranking | Cross-encoder reranker for precision |
| No evaluation | RAGAs metrics (faithfulness, relevancy) |

## Stack

- **Kafka**: confluent-kafka-python (local via Docker)
- **Embeddings**: sentence-transformers (all-MiniLM-L6-v2) — runs locally, free
- **Vector DB**: ChromaDB — local persistent store
- **Reranker**: cross-encoder/ms-marco-MiniLM-L-6-v2
- **LLM**: Groq API (Llama3-8b — free tier, fast)
- **UI**: Streamlit
- **PDF parsing**: PyMuPDF (fitz)

## Setup

```bash
# 1. Start Kafka locally
docker-compose up -d

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set env vars
cp .env.example .env
# add your GROQ_API_KEY

# 4. Start consumer (terminal 1)
python consumer/document_consumer.py

# 5. Start producer (terminal 2)
python producer/document_producer.py

# 6. Start UI (terminal 3)
streamlit run ui/app.py

# 7. Drop any PDF into /docs — watch it get indexed live
```

## Project Structure

```
kafka-rag/
├── producer/
│   └── document_producer.py     # Watches /docs, publishes to Kafka
├── consumer/
│   └── document_consumer.py     # Consumes events, embeds, stores in Chroma
├── retriever/
│   ├── embedder.py              # Embedding + chunking logic
│   ├── vector_store.py          # ChromaDB interface
│   └── reranker.py              # Cross-encoder reranking
├── ui/
│   └── app.py                   # Streamlit chat interface
├── scripts/
│   └── evaluate.py              # RAGAs evaluation script
├── docs/                        # Drop PDFs here
├── docker-compose.yml           # Kafka + Zookeeper
├── requirements.txt
└── .env.example
```
